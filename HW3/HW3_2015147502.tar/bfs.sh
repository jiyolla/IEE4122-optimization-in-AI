python3 bfs.py < input_bfs.txt
