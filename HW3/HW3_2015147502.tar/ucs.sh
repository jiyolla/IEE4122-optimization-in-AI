python3 uniform_cost_search.py < input_ucs.txt
