python3 dfs.py < input_dfs.txt
